# ⚡ Voice Studio Pro (Portable Edition)

High-performance, dyslexia-friendly neural voice dictation and AI intelligence deck.

## 🚀 Quick Start (Any Linux Machine)
1. Open this folder in terminal.
2. Run the one-time setup:
   ```bash
   ./setup.sh
   ```
3. Double-click the **Voice Studio Pro** icon on your Desktop or run:
   ```bash
   ./launch.sh
   ```

## 🎙️ Hardware & Audio Isolation
- Designed specifically for **Yamaha Steinberg UR24C** and standard audio interfaces.
- Automatic front mic hardware isolation (never bleeds desktop/podcast audio).
- Fast, local CPU neural transcription (Faster-Whisper INT8) — $0.00 cost forever.
- Direct integration with local OmniRoute (`http://localhost:20128/v1`) or cloud OpenRouter for instant summaries.
