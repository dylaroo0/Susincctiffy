#!/usr/bin/env bash
# Voice Studio Pro - One-Click Portable Setup
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=========================================="
echo "  ⚡ VOICE STUDIO PRO - PORTABLE SETUP"
echo "=========================================="

# 1. System Dependencies Check
echo "Checking system tools..."
for tool in python3 ffmpeg curl; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "❌ Missing dependency: $tool. Please install it with: sudo apt install -y $tool" >&2
    exit 1
  fi
done
echo "✓ System dependencies OK (python3, ffmpeg, curl)"

# 2. Virtual Environment Setup
VENV_DIR="$SCRIPT_DIR/.venv"
if [ ! -d "$VENV_DIR" ]; then
  echo "Creating self-contained virtual environment in $VENV_DIR..."
  python3 -m venv "$VENV_DIR"
else
  echo "✓ Virtual environment already exists."
fi

# 3. Install Faster-Whisper
echo "Installing/verifying Faster-Whisper Neural STT..."
"$VENV_DIR/bin/pip" install --quiet --upgrade pip
"$VENV_DIR/bin/pip" install --quiet faster-whisper

# 4. Pre-download Neural Weights for 100% Offline Portability
echo "Pre-caching Faster-Whisper Neural weights (distil-small.en)..."
"$VENV_DIR/bin/python" -c '
from faster_whisper import WhisperModel
print("  Downloading model weights if not present...")
WhisperModel("distil-small.en", device="cpu", compute_type="int8", download_root="'"$SCRIPT_DIR/models"'")
print("  ✓ Neural model ready for offline execution!")
'

# 5. Create Desktop Icon & Launcher
mkdir -p "$HOME/.local/share/icons" "$HOME/.local/share/applications" "$HOME/.local/bin"
cp "$SCRIPT_DIR/icon.png" "$HOME/.local/share/icons/voice-studio.png" 2>/dev/null || true
ln -sf "$SCRIPT_DIR/launch.sh" "$HOME/.local/bin/voice-studio-launch"

cat << EOF > "$HOME/Desktop/VoiceStudio.desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=Voice Studio Pro
GenericName=Voice Dictation Deck
Comment=High-Tech Voice Intelligence & Dictation Deck
Exec=$HOME/.local/bin/voice-studio-launch
Icon=$HOME/.local/share/icons/voice-studio.png
Terminal=false
Categories=AudioVideo;Utility;Audio;
StartupNotify=true
EOF

chmod +x "$HOME/Desktop/VoiceStudio.desktop"
cp "$HOME/Desktop/VoiceStudio.desktop" "$HOME/.local/share/applications/VoiceStudio.desktop"
chmod +x "$HOME/.local/share/applications/VoiceStudio.desktop"

echo "=========================================="
echo "  ✓ SETUP COMPLETE!"
echo "  • Double-click 'Voice Studio Pro' on your Desktop"
echo "  • Or run: ./launch.sh"
echo "=========================================="
