/**
 * Voice Studio Pro — Audio Intelligence Client Engine
 * Real-time Web Audio Visualizer, Faster-Whisper Neural STT & OpenRouter Generative AI
 * Cleaned for Dylan: Zero Front-Page Clutter, Dedicated Input Switcher, SOTA Offline Speech Engine
 */

document.addEventListener('DOMContentLoaded', () => {
  // Front Elements
  const masterMicBtn = document.getElementById('master-mic-btn');
  const micBtnLabel = document.getElementById('mic-btn-label');
  const recordTimerEl = document.getElementById('record-timer');
  const recordDbEl = document.getElementById('record-db');
  const canvas = document.getElementById('visualizer-canvas');
  const canvasOverlay = document.getElementById('canvas-overlay');
  const canvasCtx = canvas.getContext('2d');
  
  const draftEditor = document.getElementById('draft-editor');
  const noteTitleInput = document.getElementById('note-title-input');
  const charCountEl = document.getElementById('char-count');
  const wordCountEl = document.getElementById('word-count');
  const latencyStatEl = document.getElementById('latency-stat');
  
  const aiLoadingIndicator = document.getElementById('ai-loading-indicator');
  const aiLoadingLabel = document.getElementById('ai-loading-label');
  
  const btnCopyMaster = document.getElementById('btn-copy-master');
  const btnSaveVault = document.getElementById('btn-save-vault');
  const btnPaste = document.getElementById('btn-paste');
  const btnClear = document.getElementById('btn-clear');
  const btnUndoOriginal = document.getElementById('btn-undo-original');
  let originalRawText = '';
  
  const customPromptInput = document.getElementById('custom-prompt-input');
  const btnCustomApply    = document.getElementById('btn-custom-apply');
  const presetChips = document.querySelectorAll('.chip-preset');
  
  const micSourceSelect = document.getElementById('mic-source-select');
  const micGainSelect = document.getElementById('mic-gain-select');
  const isolationBadgeText = document.getElementById('isolation-badge-text');
  
  // Modals & Navigation
  const btnSettings = document.getElementById('btn-settings');
  const btnHistory = document.getElementById('btn-history');
  const settingsModal = document.getElementById('settings-modal');
  const historyModal = document.getElementById('history-modal');
  const closeSettingsBtn = document.getElementById('close-settings');
  const closeHistoryBtn = document.getElementById('close-history');
  const btnSaveSettings = document.getElementById('btn-save-settings');
  
  const cfgApiEndpoint = document.getElementById('cfg-api-endpoint');
  const presetOmnirouteBtn = document.getElementById('preset-omniroute');
  const presetOpenrouterBtn = document.getElementById('preset-openrouter');
  const cfgApiKey = document.getElementById('cfg-api-key');
  const cfgOpenRouterModel = document.getElementById('cfg-openrouter-model');
  const cfgTemp = document.getElementById('cfg-temp');
  const tempVal = document.getElementById('temp-val');
  const statusText = document.getElementById('status-text');
  const historyList = document.getElementById('history-list');

  // Audio State & Hardware Locking
  let audioContext = null;
  let analyser = null;
  let gainNode = null;
  let mediaStream = null;
  let mediaStreamDestination = null;
  let mediaRecorder = null;
  let recordedChunks = [];
  let isRecording = false;
  let recordStartTime = null;
  let recordTimerInterval = null;
  let animationFrameId = null;
  let currentConfig = {
    openrouter_model: 'meta-llama/llama-3.3-70b-instruct',
    temperature: 0.1,
    mic_boost: 1.5,
    selected_mic: 'mic1',
    ui_mode: 'compact'
  };

  // Configurable hotkey (loaded from localStorage)
  let dictationHotkey = localStorage.getItem('voice_studio_hotkey') || 'F8';
  const cfgHotkey = document.getElementById('cfg-hotkey');
  const cfgFont   = document.getElementById('cfg-font');

  // Hotkey capture: click field then press any key
  if (cfgHotkey) {
    cfgHotkey.value = dictationHotkey;
    cfgHotkey.addEventListener('focus', () => { cfgHotkey.value = ''; cfgHotkey.placeholder = 'Press any key...'; });
    cfgHotkey.addEventListener('keydown', (e) => {
      e.preventDefault();
      const key = e.key === ' ' ? 'Space' : e.key;
      cfgHotkey.value = key;
      cfgHotkey.blur();
    });
    cfgHotkey.addEventListener('blur', () => {
      if (!cfgHotkey.value) cfgHotkey.value = dictationHotkey;
      cfgHotkey.placeholder = 'Click then press any key...';
    });
  }

  // Hotkey dynamic UI update
  function updateHotkeyUI() {
    const hintEl = document.querySelector('.overlay-hint');
    if (hintEl) {
      if (dictationHotkey === 'Space') {
        hintEl.innerHTML = 'Ready • Press <kbd>Space</kbd>';
      } else {
        hintEl.innerHTML = `Ready • Press <kbd>${dictationHotkey}</kbd> or <kbd>Space</kbd>`;
      }
    }
    if (micBtnLabel && !isRecording) {
      micBtnLabel.textContent = `DICTATE (${dictationHotkey})`;
    }
  }
  updateHotkeyUI();


  // Font switching
  function applyFont(fontChoice) {
    const styleEl = document.getElementById('dyslexic-font-style');
    if (!styleEl) return;
    if (fontChoice === 'opendyslexic') {
      styleEl.textContent = `
        @font-face {
          font-family: 'OpenDyslexic';
          src: url('fonts/OpenDyslexic-Regular.woff2') format('woff2'),
               url('fonts/OpenDyslexic-Regular.woff') format('woff');
          font-weight: normal;
        }
        @font-face {
          font-family: 'OpenDyslexic';
          src: url('fonts/OpenDyslexic-Bold.woff2') format('woff2'),
               url('fonts/OpenDyslexic-Bold.woff') format('woff');
          font-weight: bold;
        }
        body, #draft-editor, .ai-pill-btn, .compact-tool-btn, .icon-btn {
          font-family: 'OpenDyslexic', sans-serif !important;
          letter-spacing: 0.05em;
          line-height: 1.7 !important;
        }
      `;
    } else if (fontChoice === 'mono') {
      styleEl.textContent = `body, #draft-editor { font-family: 'JetBrains Mono', monospace !important; font-size: 12.5px !important; }`;
    } else {
      styleEl.textContent = '';
    }
  }

  // Load saved font preference
  const savedFont = localStorage.getItem('voice_studio_font') || 'inter';
  if (cfgFont) cfgFont.value = savedFont;
  applyFont(savedFont);

  // Prompts
  const AI_PROMPTS = {
    succinct: "Tighten this raw voice transcript. Remove hesitation, filler words, rambling, and repetition. Keep every single fact, number, date, name, and core intent. Format cleanly for high readability.",
    bullets: "Convert this transcript into clean, punchy, high-impact bullet points. Group by logical topic if there are multiple ideas. Output ONLY the bullet list.",
    grammar: "Fix only grammar, spelling, and punctuation errors. Do NOT rephrase, change the tone, or alter the meaning. Output only the corrected text.",
    rephrase: "Rephrase this transcript for effortless readability, smooth sentence flow, and clarity while maintaining exact facts and meaning.",
    pro: "Rewrite this in formal, polished, executive business English. Keep it direct, structured, and factual.",
    artsy: "Rewrite this with expressive, evocative, and creative narrative language while preserving the underlying message.",
    expand: "Elaborate and expand on these ideas with clear structure, logical explanations, and supporting context while preserving the speaker's true intent."
  };

  // Canvas Sizing
  function resizeCanvas() {
    canvas.width = canvas.parentElement.clientWidth * window.devicePixelRatio;
    canvas.height = canvas.parentElement.clientHeight * window.devicePixelRatio;
    canvasCtx.scale(window.devicePixelRatio, window.devicePixelRatio);
  }
  window.addEventListener('resize', resizeCanvas);
  setTimeout(resizeCanvas, 100);

  // Preset Endpoints
  if (presetOmnirouteBtn) {
    presetOmnirouteBtn.addEventListener('click', () => {
      cfgApiEndpoint.value = 'http://localhost:20128/v1';
      cfgApiKey.value = 'sk-9f16733d6ff2ea5c-4a9fc1-6c8630db';
      cfgOpenRouterModel.value = 'openrouter/meta-llama/llama-3.3-70b-instruct';
      showToast('Set to OmniRoute Hub (localhost:20128)', 'info');
    });
  }

  if (presetOpenrouterBtn) {
    presetOpenrouterBtn.addEventListener('click', () => {
      cfgApiEndpoint.value = 'https://openrouter.ai/api/v1';
      cfgOpenRouterModel.value = 'meta-llama/llama-3.3-70b-instruct';
      showToast('Set to Direct OpenRouter Cloud', 'info');
    });
  }

  // Load Settings from Server
  async function loadConfig() {
    try {
      const res = await fetch('/api/config');
      currentConfig = await res.json();
      if (cfgApiEndpoint) {
        cfgApiEndpoint.value = currentConfig.api_endpoint || 'http://localhost:20128/v1';
      }
      if (cfgApiKey) {
        cfgApiKey.value = currentConfig.api_key || currentConfig.openrouter_api_key || 'sk-9f16733d6ff2ea5c-4a9fc1-6c8630db';
      }
      if (cfgOpenRouterModel) {
        cfgOpenRouterModel.value = currentConfig.model || currentConfig.openrouter_model || 'openrouter/meta-llama/llama-3.3-70b-instruct';
      }
      cfgTemp.value = currentConfig.temperature ?? 0.1;
      updateTempDisplay();

      if (micGainSelect && currentConfig.mic_boost) {
        micGainSelect.value = String(currentConfig.mic_boost);
      }

      const savedMic = localStorage.getItem('voice_studio_mic') || currentConfig.selected_mic || 'mic1';
      if (micSourceSelect) {
        micSourceSelect.value = savedMic;
        updateIsolationLabel(savedMic);
      }

    } catch (e) {
      console.warn('Could not load config from server:', e);
    }
  }
  loadConfig();

  function updateTempDisplay() {
    const val = parseFloat(cfgTemp.value);
    tempVal.textContent = `${val.toFixed(2)} (${val < 0.3 ? 'Strict & Factual' : val < 0.7 ? 'Balanced' : 'Creative'})`;
  }
  cfgTemp.addEventListener('input', updateTempDisplay);

  function updateIsolationLabel(micVal) {
    if (!isolationBadgeText) return;
    if (micVal === 'mic1') {
      isolationBadgeText.textContent = 'MIC 1 ISOLATED • PODCAST BLOCKED';
    } else if (micVal === 'mic2') {
      isolationBadgeText.textContent = 'MIC 2 ISOLATED • PODCAST BLOCKED';
    } else if (micVal === 'both') {
      isolationBadgeText.textContent = 'STEREO MICS 1+2 • PODCAST BLOCKED';
    } else {
      isolationBadgeText.textContent = 'DESKTOP AUDIO LOOPBACK (PODCASTS ACTIVE)';
    }
  }

  // Mic Source Selection
  if (micSourceSelect) {
    micSourceSelect.addEventListener('change', async () => {
      const selected = micSourceSelect.value;
      localStorage.setItem('voice_studio_mic', selected);
      updateIsolationLabel(selected);

      try {
        await fetch('/api/set-mic', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ mic: selected })
        });
        showToast(`Switched input to: ${micSourceSelect.options[micSourceSelect.selectedIndex].text}`, 'success');
        await initAudio();
      } catch (e) {
        console.warn('Failed to set mic source:', e);
      }
    });
  }

  // Mic Pre-amp Boost
  if (micGainSelect) {
    micGainSelect.addEventListener('change', () => {
      const val = parseFloat(micGainSelect.value);
      if (gainNode && audioContext) {
        gainNode.gain.setValueAtTime(val, audioContext.currentTime);
      }
      showToast(`Mic boost set to ${val}x`, 'info');
      fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mic_boost: val })
      }).catch(e => console.warn(e));
    });
  }

  // Setup Web Audio Graph
  async function initAudio() {
    if (!audioContext) {
      audioContext = new (window.AudioContext || window.webkitAudioContext)({
        sampleRate: 48000
      });
    }
    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }

    const gainValue = parseFloat(micGainSelect ? micGainSelect.value : 1.5);
    const micMode = micSourceSelect ? micSourceSelect.value : 'mic1';

    const constraints = {
      audio: micMode === 'desktop' ? {
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false
      } : {
        channelCount: micMode === 'both' ? { ideal: 2 } : { ideal: 1 },
        echoCancellation: { ideal: true },
        noiseSuppression: { ideal: true },
        autoGainControl: { ideal: true }
      }
    };

    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
    }

    mediaStream = await navigator.mediaDevices.getUserMedia(constraints);

    const source = audioContext.createMediaStreamSource(mediaStream);

    gainNode = audioContext.createGain();
    gainNode.gain.setValueAtTime(gainValue, audioContext.currentTime);

    analyser = audioContext.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.8;

    source.connect(gainNode);
    gainNode.connect(analyser);

    mediaStreamDestination = audioContext.createMediaStreamDestination();
    gainNode.connect(mediaStreamDestination);

    drawVisualizer();
  }

  // Real-Time Studio Equalizer & Live VU Monitor
  const NUM_EQ_BARS = 36;
  const peakHeights = new Array(NUM_EQ_BARS).fill(0);

  function drawVisualizer() {
    const parent = canvas.parentElement;
    const width = parent ? parent.clientWidth : 400;
    const height = parent ? parent.clientHeight : 100;

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    canvasCtx.clearRect(0, 0, width, height);

    const gap = 3;
    const totalGap = gap * (NUM_EQ_BARS + 1);
    const barWidth = Math.max(3, (width - totalGap) / NUM_EQ_BARS);

    if (!analyser) {
      // Standby alive animation: subtle undulating cyan-emerald equalizer wave
      const t = Date.now() * 0.003;
      if (recordDbEl && recordDbEl.textContent !== 'STANDBY') {
        recordDbEl.textContent = 'STANDBY';
      }

      for (let i = 0; i < NUM_EQ_BARS; i++) {
        const wave = Math.sin(t + i * 0.22) * 0.5 + 0.5;
        const wave2 = Math.cos(t * 0.7 + i * 0.15) * 0.5 + 0.5;
        const barHeight = Math.max(4, (wave * 0.6 + wave2 * 0.4) * (height * 0.35));
        const x = gap + i * (barWidth + gap);
        const y = height - barHeight;

        const grad = canvasCtx.createLinearGradient(0, y, 0, height);
        grad.addColorStop(0, 'rgba(0, 240, 255, 0.75)');
        grad.addColorStop(1, 'rgba(0, 255, 136, 0.15)');

        canvasCtx.fillStyle = grad;
        canvasCtx.fillRect(x, y, barWidth, barHeight);

        // Peak cap
        canvasCtx.fillStyle = '#00f0ff';
        canvasCtx.fillRect(x, Math.max(0, y - 2), barWidth, 2);
      }

      animationFrameId = requestAnimationFrame(drawVisualizer);
      return;
    }

    // Active mic or recording FFT
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyser.getByteFrequencyData(dataArray);

    let sum = 0;
    for (let i = 0; i < bufferLength; i++) {
      sum += dataArray[i] * dataArray[i];
    }
    const rms = Math.sqrt(sum / bufferLength);
    const db = rms > 0 ? Math.round(20 * Math.log10(rms / 255)) : -100;
    if (recordDbEl) {
      recordDbEl.textContent = `${db} dB`;
      if (isRecording) {
        recordDbEl.style.color = '#ff3366';
      } else {
        recordDbEl.style.color = rms > 15 ? '#00ff88' : '#00f0ff';
      }
    }

    // Downsample frequency data into 36 studio frequency bins with perceptual scaling
    const binSize = Math.max(1, Math.floor((bufferLength * 0.75) / NUM_EQ_BARS));
    for (let i = 0; i < NUM_EQ_BARS; i++) {
      let binSum = 0;
      const startBin = i * binSize;
      for (let j = 0; j < binSize && (startBin + j) < bufferLength; j++) {
        binSum += dataArray[startBin + j];
      }
      const binAvg = binSum / binSize;

      // Dynamic boost for high frequencies so they don't look flat
      const freqBoost = 1.0 + (i / NUM_EQ_BARS) * 0.8;
      const normalized = Math.min(1.0, (binAvg / 255) * freqBoost);
      const targetBarHeight = Math.max(4, normalized * (height * 0.94));

      // Peak cap falloff with gravity
      if (targetBarHeight >= peakHeights[i]) {
        peakHeights[i] = targetBarHeight;
      } else {
        peakHeights[i] = Math.max(4, peakHeights[i] - 1.8);
      }

      const x = gap + i * (barWidth + gap);
      const y = height - targetBarHeight;

      const gradient = canvasCtx.createLinearGradient(0, y, 0, height);
      if (isRecording) {
        gradient.addColorStop(0, '#ff3366');
        gradient.addColorStop(0.5, '#ff9900');
        gradient.addColorStop(1, 'rgba(255, 51, 102, 0.2)');
      } else {
        gradient.addColorStop(0, '#00f0ff');
        gradient.addColorStop(0.5, '#00ff88');
        gradient.addColorStop(1, 'rgba(0, 255, 136, 0.15)');
      }

      canvasCtx.fillStyle = gradient;
      canvasCtx.fillRect(x, y, barWidth, targetBarHeight);

      // Draw glowing studio peak cap
      const peakY = height - peakHeights[i];
      canvasCtx.fillStyle = isRecording ? '#ffaa00' : '#00f0ff';
      canvasCtx.fillRect(x, Math.max(0, peakY - 2), barWidth, 2);
    }

    animationFrameId = requestAnimationFrame(drawVisualizer);
  }

  // Start Recording
  async function startRecording() {
    try {
      if (!audioContext || !mediaStream || !mediaStream.active) {
        await initAudio();
      }
      recordedChunks = [];
      
      const mimeTypes = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg', 'audio/wav'];
      let selectedMime = '';
      for (const m of mimeTypes) {
        if (MediaRecorder.isTypeSupported(m)) {
          selectedMime = m;
          break;
        }
      }

      const recordStream = mediaStreamDestination ? mediaStreamDestination.stream : mediaStream;
      mediaRecorder = new MediaRecorder(recordStream, selectedMime ? { mimeType: selectedMime } : undefined);

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunks.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(recordedChunks, { type: selectedMime || 'audio/webm' });
        await processAudioTranscription(audioBlob);
      };

      mediaRecorder.start(250);
      isRecording = true;
      recordStartTime = Date.now();

      // UI Updates
      masterMicBtn.classList.add('recording');
      micBtnLabel.textContent = `STOP (${dictationHotkey})`;
      canvasOverlay.classList.add('hidden');
      statusText.textContent = '● Recording... Speak freely';
      statusText.style.color = '#ff3366';

      recordTimerInterval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - recordStartTime) / 1000);
        const mins = String(Math.floor(elapsed / 60)).padStart(2, '0');
        const secs = String(elapsed % 60).padStart(2, '0');
        const timeStr = `${mins}:${secs}`;
        recordTimerEl.textContent = timeStr;
      }, 500);

    } catch (err) {
      console.error('Failed to start recording:', err);
      showToast(`Microphone access error: ${err.message}`, 'error');
    }
  }

  // Stop Recording
  function stopRecording() {
    if (!isRecording || !mediaRecorder) return;
    
    isRecording = false;
    clearInterval(recordTimerInterval);
    
    masterMicBtn.classList.remove('recording');
    micBtnLabel.textContent = 'TRANSCRIBING...';
    statusText.textContent = '⏳ Faster-Whisper Neural processing...';
    statusText.style.color = '#ffaa00';

    if (mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
    }
    // KEEP stream open so input mic NEVER resets!
  }

  // Toggle Recording
  function toggleRecording() {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  }

  masterMicBtn.addEventListener('click', toggleRecording);

  // Process Transcription on Server via Faster-Whisper Neural
  async function processAudioTranscription(blob) {
    aiLoadingIndicator.classList.remove('hidden');
    aiLoadingLabel.textContent = 'Transcribing with Faster-Whisper Neural...';

    try {
      const res = await fetch('/api/transcribe', {
        method: 'POST',
        body: blob
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Transcription failed');
      }

      const text = data.text.trim();
      if (text) {
        const current = draftEditor.value.trim();
        originalRawText = current ? `${current}\n\n${text}` : text;
        draftEditor.value = originalRawText;
        updateStats();

        // Always copy transcript to clipboard ("copy as a law")
        await copyToClipboard(originalRawText, false);

        if (btnUndoOriginal) btnUndoOriginal.style.display = 'none';

        showToast(`✓ Transcribed & copied to clipboard (${data.duration}s in ${data.latency}s)`, 'success');
        latencyStatEl.textContent = `⚡ Transcribed ${data.duration}s in ${data.latency}s (${data.engine}) • AI: ${(currentConfig.openrouter_model || '').split('/').pop()}`;
      } else {
        showToast('No speech detected. Try speaking closer to your mic.', 'error');
      }
    } catch (err) {
      console.error('Transcription error:', err);
      showToast(`Transcription error: ${err.message}`, 'error');
    } finally {
      aiLoadingIndicator.classList.add('hidden');
      micBtnLabel.textContent = `DICTATE (${dictationHotkey})`;
      canvasOverlay.classList.remove('hidden');
      statusText.textContent = 'Yamaha Steinberg UR24C Ready';
      statusText.style.color = '#00ff88';
      if (recordDbEl) recordDbEl.textContent = '-inf dB';
    }
  }

  // AI Transformations
  async function runAiTransformation(action, customPrompt = '') {
    const text = draftEditor.value.trim();
    if (!text) {
      showToast('Please dictate or type text first!', 'error');
      draftEditor.focus();
      return;
    }

    const prompt = customPrompt || AI_PROMPTS[action];
    if (!prompt) return;

    aiLoadingIndicator.classList.remove('hidden');
    const activeModelShort = (currentConfig.openrouter_model || 'AI').split('/').pop();
    aiLoadingLabel.textContent = `Running ${action.toUpperCase()} with ${activeModelShort}...`;

    try {
      const res = await fetch('/api/transform', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt,
          text: text,
          model: currentConfig.model || currentConfig.openrouter_model || 'openrouter/meta-llama/llama-3.3-70b-instruct',
          temperature: parseFloat(currentConfig.temperature ?? 0.1)
        })
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'AI request failed');
      }

      // Save pre-AI text as original copy if not already stored
      if (!originalRawText) {
        originalRawText = text;
      }
      if (btnUndoOriginal) {
        btnUndoOriginal.style.display = 'inline-flex';
      }

      draftEditor.value = data.result;
      updateStats();

      // Auto-copy transformed result to clipboard ("second copy")
      await copyToClipboard(data.result, false);

      showToast(`✓ ${action.toUpperCase()} completed & copied!`, 'success');
      latencyStatEl.textContent = `AI enhanced in ${data.latency}s • Model: ${(currentConfig.openrouter_model || '').split('/').pop()}`;

    } catch (err) {
      console.error('Transformation error:', err);
      showToast(`AI error: ${err.message}`, 'error');
    } finally {
      aiLoadingIndicator.classList.add('hidden');
    }
  }

  // Undo / Revert to Original Raw Speech
  if (btnUndoOriginal) {
    btnUndoOriginal.addEventListener('click', async () => {
      if (originalRawText) {
        draftEditor.value = originalRawText;
        updateStats();
        btnUndoOriginal.style.display = 'none';
        await copyToClipboard(originalRawText, false);
        showToast('↺ Restored raw speech & copied to clipboard!', 'info');
      }
    });
  }

  // Attach AI Button Handlers
  document.querySelectorAll('.ai-pill-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const action = btn.getAttribute('data-action');
      runAiTransformation(action);
    });
  });

  if (btnCustomApply) {
    btnCustomApply.addEventListener('click', () => {
      const custom = customPromptInput ? customPromptInput.value.trim() : '';
      if (!custom) {
        showToast('Type a custom instruction first!', 'error');
        if (customPromptInput) customPromptInput.focus();
        return;
      }
      runAiTransformation('custom', `Rewrite this text ${custom}. Maintain core facts:`);
    });
  }

  if (presetChips.length) {
    presetChips.forEach(chip => {
      chip.addEventListener('click', () => {
        if (customPromptInput) customPromptInput.value = chip.getAttribute('data-prompt');
        if (btnCustomApply) btnCustomApply.click();
      });
    });
  }

  // Copy to Clipboard
  async function copyToClipboard(text, showNotification = true) {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      if (showNotification) {
        showToast('📋 Copied draft to clipboard!', 'success');
      }
    } catch (e) {
      draftEditor.select();
      document.execCommand('copy');
      if (showNotification) {
        showToast('📋 Copied draft to clipboard!', 'success');
      }
    }
  }

  btnCopyMaster.addEventListener('click', () => {
    copyToClipboard(draftEditor.value.trim(), true);
  });

  // Paste Tool
  btnPaste.addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        const current = draftEditor.value.trim();
        draftEditor.value = current ? `${current}\n\n${text}` : text;
        updateStats();
        showToast('Pasted from clipboard', 'success');
      }
    } catch (e) {
      showToast('Clipboard access denied. Use Ctrl+V', 'error');
    }
  });

  // Clear Tool (Immediate & Undo-Safe)
  btnClear.addEventListener('click', () => {
    if (!draftEditor.value.trim() && !noteTitleInput.value.trim()) {
      showToast('Nothing to clear', 'info');
      return;
    }
    originalRawText = draftEditor.value;
    draftEditor.value = '';
    noteTitleInput.value = '';
    updateStats();
    if (btnUndoOriginal) btnUndoOriginal.style.display = 'inline-flex';
    showToast('Draft cleared. Click ↺ Original to undo', 'info');
  });

  // Save to Vault
  btnSaveVault.addEventListener('click', async () => {
    const text = draftEditor.value.trim();
    if (!text) {
      showToast('Draft is empty! Dictate something before saving.', 'error');
      return;
    }

    const title = noteTitleInput.value.trim() || 'Dictation Session';

    try {
      const res = await fetch('/api/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title,
          text: text,
          action: 'Voice Studio'
        })
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to save');
      }

      showToast(`💾 Saved to Vault: ${data.filename}`, 'success');
    } catch (e) {
      showToast(`Save error: ${e.message}`, 'error');
    }
  });

  // History Drawer
  btnHistory.addEventListener('click', async () => {
    historyModal.classList.remove('hidden');
    try {
      const res = await fetch('/api/history');
      const items = await res.json();
      if (!items.length) {
        historyList.innerHTML = '<div class="history-empty">No saved dictations found yet in your vault.</div>';
        return;
      }

      historyList.innerHTML = items.map(item => `
        <div class="history-item" data-filename="${item.filename}">
          <div class="history-item-header">
            <span class="history-title">${item.filename}</span>
            <span class="history-time">${item.timestamp}</span>
          </div>
          <div class="history-preview">${item.preview}</div>
        </div>
      `).join('');

      document.querySelectorAll('.history-item').forEach(el => {
        el.addEventListener('click', async () => {
          const fname = el.getAttribute('data-filename');
          const noteRes = await fetch(`/api/note/${encodeURIComponent(fname)}`);
          if (noteRes.ok) {
            const content = await noteRes.text();
            draftEditor.value = content;
            noteTitleInput.value = fname.replace(/^\d{4}-\d{2}-\d{2}-\d{4}_/, '').replace(/\.md$/, '');
            updateStats();
            historyModal.classList.add('hidden');
            showToast(`Loaded ${fname} into editor`, 'success');
          }
        });
      });

    } catch (e) {
      historyList.innerHTML = `<div class="history-empty error">Failed to load history: ${e.message}</div>`;
    }
  });

  closeHistoryBtn.addEventListener('click', () => {
    historyModal.classList.add('hidden');
    historyModal.style.display = 'none';
  });

  // Settings Modal
  btnSettings.addEventListener('click', () => {
    settingsModal.classList.remove('hidden');
    settingsModal.style.display = 'flex';
  });
  closeSettingsBtn.addEventListener('click', () => {
    settingsModal.classList.add('hidden');
    settingsModal.style.display = 'none';
  });

  // Modal Escape & backdrop click handlers (never get stuck)
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      settingsModal.classList.add('hidden');
      settingsModal.style.display = 'none';
      historyModal.classList.add('hidden');
      historyModal.style.display = 'none';
      const cm = document.getElementById('custom-model-modal');
      if (cm) cm.classList.add('hidden');
    }
  });
  settingsModal.addEventListener('click', (e) => {
    if (e.target === settingsModal) {
      settingsModal.classList.add('hidden');
      settingsModal.style.display = 'none';
    }
  });
  historyModal.addEventListener('click', (e) => {
    if (e.target === historyModal) {
      historyModal.classList.add('hidden');
      historyModal.style.display = 'none';
    }
  });

  // Save Settings
  btnSaveSettings.addEventListener('click', async () => {
    let chosenModel = cfgOpenRouterModel.value;
    if (chosenModel === '__custom__') {
      const custom = prompt('Enter custom model slug (e.g. openrouter/deepseek/deepseek-r1 or auto/fast):');
      if (custom && custom.trim()) {
        chosenModel = custom.trim();
      } else {
        chosenModel = currentConfig.model || currentConfig.openrouter_model || 'openrouter/meta-llama/llama-3.3-70b-instruct';
      }
    }

    // Save hotkey
    if (cfgHotkey && cfgHotkey.value) {
      dictationHotkey = cfgHotkey.value;
      localStorage.setItem('voice_studio_hotkey', dictationHotkey);
    }

    // Save font
    if (cfgFont) {
      const fontChoice = cfgFont.value;
      localStorage.setItem('voice_studio_font', fontChoice);
      applyFont(fontChoice);
    }

    const newCfg = {
      api_endpoint: (cfgApiEndpoint ? cfgApiEndpoint.value.trim() : 'http://localhost:20128/v1'),
      api_key: (cfgApiKey ? cfgApiKey.value.trim() : ''),
      openrouter_api_key: (cfgApiKey ? cfgApiKey.value.trim() : ''),
      model: chosenModel,
      openrouter_model: chosenModel,
      temperature: parseFloat(cfgTemp.value),
      mic_boost: parseFloat(micGainSelect ? micGainSelect.value : 1.5)
    };

    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCfg)
      });
      const data = await res.json();
      if (data.success) {
        currentConfig = data.config;
        settingsModal.classList.add('hidden');
        updateHotkeyUI();
        const hubLabel = (currentConfig.api_endpoint || '').includes('20128') ? 'OmniRoute Hub' : 'OpenRouter';
        showToast(`Settings saved! [${hubLabel}] Hotkey: ${dictationHotkey}`, 'success');
      }
    } catch (e) {
      showToast(`Save settings error: ${e.message}`, 'error');
    }
  });

  // Global Keyboard Shortcuts — hotkey is now fully configurable
  window.addEventListener('keydown', (e) => {
    // Match configured hotkey
    const keyMatch = e.key === dictationHotkey ||
                     (dictationHotkey === 'Space' && e.code === 'Space');

    if (keyMatch && document.activeElement !== draftEditor &&
        document.activeElement !== noteTitleInput &&
        document.activeElement !== cfgHotkey) {
      e.preventDefault();
      toggleRecording();
      return;
    }

    // Space fallback (only if hotkey isn't already Space)
    if (dictationHotkey !== 'Space' && e.code === 'Space' &&
        document.activeElement !== draftEditor &&
        document.activeElement !== noteTitleInput &&
        document.activeElement !== cfgHotkey) {
      e.preventDefault();
      toggleRecording();
      return;
    }

    if (e.key === 'Escape') {
      settingsModal.classList.add('hidden');
      historyModal.classList.add('hidden');
    }
  });

  // Text Stats Updater
  function updateStats() {
    const val = draftEditor.value;
    charCountEl.textContent = `${val.length} chars`;
    const words = val.trim() ? val.trim().split(/\s+/).length : 0;
    wordCountEl.textContent = `${words} words`;
  }
  draftEditor.addEventListener('input', updateStats);

  // Toast Notification Engine
  function showToast(msg, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = msg;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  // Initialize Audio immediately on load so mic is locked and ready
  initAudio().catch(e => console.warn('Auto-init audio deferred:', e));
});
