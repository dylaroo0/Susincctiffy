#!/usr/bin/env python3
"""
Voice Studio Pro — High-Tech Speech-to-Text & Generative Transformation Suite
Built for Dylan / Vault Studio Operations.
"""

import http.server
import socketserver
import json
import os
import sys
import subprocess
import wave
import io
import time
from datetime import datetime
import urllib.request
import urllib.error

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
VAULT_DIR = "/home/roo/Documents/PROJECTS OF FOCUS/vault"
DICTATIONS_DIR = os.path.join(VAULT_DIR, "dictations")
CONFIG_PATH = os.path.expanduser("~/voice_studio_config.json")
VOSK_MODEL_DIR = os.path.expanduser("~/.local/share/nerd-dictation/model")

os.makedirs(DICTATIONS_DIR, exist_ok=True)
os.makedirs(STATIC_DIR, exist_ok=True)

# Ensure Hardware-Isolated Steinberg Inputs in PipeWire (Excludes loopback AUX2 & AUX3)
def ensure_isolated_mics():
    try:
        res = subprocess.check_output(["pactl", "list", "sources", "short"], text=True)
        # Mic 1 (AUX0)
        if "Steinberg_Mic_Only" not in res:
            subprocess.run([
                "pactl", "load-module", "module-remap-source",
                "source_name=Steinberg_Mic_Only",
                "master=alsa_input.usb-Yamaha_Corporation_Steinberg_UR24C-00.pro-input-0",
                "master_channels=AUX0",
                "channels=1",
                "channel_map=mono"
            ], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        # Mic 2 (AUX1)
        if "Steinberg_Mic2" not in res:
            subprocess.run([
                "pactl", "load-module", "module-remap-source",
                "source_name=Steinberg_Mic2",
                "master=alsa_input.usb-Yamaha_Corporation_Steinberg_UR24C-00.pro-input-0",
                "master_channels=AUX1",
                "channels=1",
                "channel_map=mono"
            ], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        # Both Mics Stereo (AUX0 + AUX1)
        if "Steinberg_Stereo_Mics" not in res:
            subprocess.run([
                "pactl", "load-module", "module-remap-source",
                "source_name=Steinberg_Stereo_Mics",
                "master=alsa_input.usb-Yamaha_Corporation_Steinberg_UR24C-00.pro-input-0",
                "master_channels=AUX0,AUX1",
                "channels=2",
                "channel_map=front-left,front-right"
            ], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("[VOICE_STUDIO] Hardware-isolated Steinberg Mic 1, Mic 2 & Stereo sources ready.")
    except Exception as e:
        print(f"[VOICE_STUDIO] Mic isolation notice: {e}")

ensure_isolated_mics()

# Load Primary Modern Neural STT: Faster-Whisper
_whisper_model = None
try:
    from faster_whisper import WhisperModel
    print("[VOICE_STUDIO] Loading Modern Neural STT: faster-whisper (distil-small.en)...")
    _whisper_model = WhisperModel("base.en", device="cpu", compute_type="int8", cpu_threads=4)
    print("[VOICE_STUDIO] faster-whisper base.en loaded successfully!")
except Exception as e:
    print(f"[VOICE_STUDIO] Whisper load warning: {e}")

# Preload Vosk as legacy fallback
_vosk_model = None
try:
    import vosk
    vosk.SetLogLevel(-1)
    if os.path.exists(VOSK_MODEL_DIR):
        _vosk_model = vosk.Model(VOSK_MODEL_DIR)
except Exception as e:
    pass

DEFAULT_CONFIG = {
    "api_endpoint": "http://localhost:20128/v1",
    "api_key": "sk-9f16733d6ff2ea5c-4a9fc1-6c8630db",
    "model": "openrouter/meta-llama/llama-3.3-70b-instruct",
    "openrouter_api_key": "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",
    "openrouter_model": "openrouter/meta-llama/llama-3.3-70b-instruct",
    "temperature": 0.1,
    "hotkey": "F8",
    "theme": "cyber-dark",
    "mic_boost": 1.5,
    "selected_mic": "mic1",
    "noise_suppression": True,
    "echo_cancellation": True
}

MIC_MAP = {
    "mic1": "Steinberg_Mic_Only",
    "mic2": "Steinberg_Mic2",
    "both": "Steinberg_Stereo_Mics",
    "desktop": "alsa_output.usb-Yamaha_Corporation_Steinberg_UR24C-00.pro-output-0.monitor"
}

def apply_mic_source(key):
    source_node = MIC_MAP.get(key, "Steinberg_Mic_Only")
    subprocess.run(["pactl", "set-default-source", source_node], check=False)

FEATURED_MODELS = [
    {"id": "openrouter/meta-llama/llama-3.3-70b-instruct", "name": "Llama 3.3 70B (OpenRouter)", "provider": "Meta", "badge": "0.7s Flash", "desc": "Sub-second intelligence via OmniRoute"},
    {"id": "auto/fast", "name": "OmniRoute Auto Fast", "provider": "OmniRoute", "badge": "Smart Combo", "desc": "Fastest available healthy model across your accounts"},
    {"id": "auto/cheap", "name": "OmniRoute Auto Cheap", "provider": "OmniRoute", "badge": "Free / Dirt Cheap", "desc": "Cost-optimized routing"},
    {"id": "agy/gemini-3.1-flash-lite", "name": "Gemini 3.1 Flash Lite", "provider": "Antigravity", "badge": "Instant Google", "desc": "Ultra snappy through your Antigravity login"},
    {"id": "openrouter/google/gemini-2.5-flash-lite", "name": "Gemini 2.5 Flash Lite", "provider": "Google", "badge": "0.075 / 1M", "desc": "Dirt cheap Google intelligence"},
    {"id": "openrouter/deepseek/deepseek-chat-v3.1", "name": "DeepSeek V3.1", "provider": "DeepSeek", "badge": "Smart Coder", "desc": "Dense high-IQ distillation"},
    {"id": "agy/claude-sonnet-4-6", "name": "Claude Sonnet 4.6", "provider": "Antigravity", "badge": "Prose Master", "desc": "Premier Anthropic via Antigravity"}
]

def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                saved = json.load(f)
            for k in DEFAULT_CONFIG:
                if k in saved and saved[k]:
                    cfg[k] = saved[k]
        except Exception:
            pass
    return cfg

def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w") as f:
            json.dump(cfg, f, indent=2)
    except Exception as e:
        print(f"Error saving config: {e}")

# Ensure config exists
current_config = load_config()
save_config(current_config)

def transcribe_audio_bytes(audio_data):
    """Converts audio blob to 16kHz mono PCM wav via ffmpeg, then runs Faster-Whisper with VAD"""
    # Run ffmpeg to transcode any format (webm/ogg/wav) to 16kHz 16-bit mono PCM wav
    ffmpeg_cmd = [
        "ffmpeg", "-y", "-loglevel", "quiet",
        "-i", "pipe:0",
        "-ar", "16000",
        "-ac", "1",
        "-f", "wav",
        "pipe:1"
    ]
    p = subprocess.Popen(ffmpeg_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    wav_data, err = p.communicate(input=audio_data)
    
    if p.returncode != 0 or not wav_data:
        raise Exception(f"Audio conversion failed: {err.decode('utf-8', errors='ignore')[:150]}")
    
    wf = wave.open(io.BytesIO(wav_data), 'rb')
    duration = wf.getnframes() / float(wf.getframerate())

    # Modern SOTA Engine: Faster-Whisper with Silero VAD
    if _whisper_model:
        bio = io.BytesIO(wav_data)
        segments, info = _whisper_model.transcribe(
            bio,
            beam_size=2,
            language="en",
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=1000, speech_pad_ms=400)
        )
        text_parts = [s.text.strip() for s in segments if s.text.strip()]
        text = " ".join(text_parts).strip()
        engine_name = "Whisper Neural (base.en)"
        return text, round(duration, 2), engine_name
    
    # Fallback: Vosk
    elif _vosk_model:
        import vosk
        rec = vosk.KaldiRecognizer(_vosk_model, 16000)
        rec.SetWords(True)
        wf.rewind()
        while True:
            data = wf.readframes(4000)
            if len(data) == 0:
                break
            rec.AcceptWaveform(data)
        res = json.loads(rec.FinalResult())
        text = res.get("text", "").strip()
        return text, round(duration, 2), "Vosk (Legacy)"
    
    raise Exception("No speech recognition engine available.")

def call_openrouter(prompt, text, model=None, temp=0.1):
    cfg = load_config()
    api_endpoint = cfg.get("api_endpoint", "http://localhost:20128/v1").strip().rstrip("/")
    if not api_endpoint:
        api_endpoint = "http://localhost:20128/v1"
        
    api_key = cfg.get("api_key", "").strip() or cfg.get("openrouter_api_key", "").strip()
    if not api_key:
        if "localhost:20128" in api_endpoint:
            api_key = "sk-9f16733d6ff2ea5c-4a9fc1-6c8630db"
        else:
            raise Exception("No API key found in configuration.")
    
    model = model or cfg.get("model") or cfg.get("openrouter_model", "openrouter/meta-llama/llama-3.3-70b-instruct")
    
    payload = {
        "model": model,
        "temperature": float(temp),
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are the Voice Studio Pro AI transformation engine for Dylan. "
                    "You excel at producing high-impact, dyslexia-friendly, concise, and structured output. "
                    "Rules: Preserve all facts, names, dates, numbers, and core intent. "
                    "Never hallucinate new facts. Strip out rambling, hesitation, and verbal filler. "
                    "Output ONLY the transformed text without chat commentary or preface."
                )
            },
            {
                "role": "user",
                "content": f"{prompt}\n\n[INPUT TEXT]:\n{text}"
            }
        ]
    }
    
    target_url = f"{api_endpoint}/chat/completions"
    req = urllib.request.Request(
        target_url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://github.com/dylaroo/vault",
            "X-Title": "Voice Studio Pro"
        },
        method="POST"
    )
    
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"].strip()
    except urllib.error.HTTPError as e:
        error_msg = e.read().decode("utf-8", errors="ignore")
        raise Exception(f"AI Hub HTTP {e.code}: {error_msg[:250]}")
    except Exception as e:
        raise Exception(f"AI generation failed: {e}")

class StudioRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=STATIC_DIR, **kwargs)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        if self.path == "/api/config":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(load_config()).encode("utf-8"))
            return
        elif self.path == "/api/models":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(FEATURED_MODELS).encode("utf-8"))
            return
        elif self.path == "/api/history":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            # Scan dictations dir
            items = []
            try:
                for fname in sorted(os.listdir(DICTATIONS_DIR), reverse=True)[:25]:
                    if fname.endswith(".md"):
                        fpath = os.path.join(DICTATIONS_DIR, fname)
                        mtime = os.path.getmtime(fpath)
                        with open(fpath, "r", encoding="utf-8") as f:
                            snippet = f.read(250).replace("\n", " ")
                        items.append({
                            "filename": fname,
                            "timestamp": datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M"),
                            "preview": snippet
                        })
            except Exception as e:
                print(f"Error reading history: {e}")
            self.wfile.write(json.dumps(items).encode("utf-8"))
            return
        elif self.path.startswith("/api/note/"):
            fname = os.path.basename(self.path[len("/api/note/"):])
            fpath = os.path.join(DICTATIONS_DIR, fname)
            if os.path.exists(fpath):
                self.send_response(200)
                self.send_header("Content-Type", "text/markdown; charset=utf-8")
                self.end_headers()
                with open(fpath, "rb") as f:
                    self.wfile.write(f.read())
                return
            else:
                self.send_response(404)
                self.end_headers()
                return

        super().do_GET()

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        
        # Audio Transcription endpoint
        if self.path == "/api/transcribe":
            audio_bytes = self.rfile.read(content_length)
            if not audio_bytes:
                self._send_json({"error": "Empty audio received"}, status=400)
                return
            
            try:
                t0 = time.time()
                text, duration, engine = transcribe_audio_bytes(audio_bytes)
                latency = round(time.time() - t0, 2)
                self._send_json({
                    "success": True,
                    "text": text,
                    "duration": duration,
                    "latency": latency,
                    "engine": engine
                })
            except Exception as e:
                self._send_json({"error": str(e)}, status=500)
            return

        # AI Transformation endpoint
        elif self.path == "/api/transform":
            body = self.rfile.read(content_length).decode("utf-8")
            try:
                data = json.loads(body)
                prompt = data.get("prompt", "")
                text = data.get("text", "")
                model = data.get("model")
                temp = data.get("temperature", 0.1)
                
                if not text.strip():
                    self._send_json({"error": "No text provided"}, status=400)
                    return
                
                t0 = time.time()
                result = call_openrouter(prompt, text, model=model, temp=temp)
                latency = round(time.time() - t0, 2)
                self._send_json({
                    "success": True,
                    "result": result,
                    "latency": latency
                })
            except Exception as e:
                self._send_json({"error": str(e)}, status=500)
            return

        # Save to Vault endpoint
        elif self.path == "/api/save":
            body = self.rfile.read(content_length).decode("utf-8")
            try:
                data = json.loads(body)
                text = data.get("text", "").strip()
                title = data.get("title", "").strip()
                action = data.get("action", "Raw Dictation")
                
                if not text:
                    self._send_json({"error": "Empty note"}, status=400)
                    return
                
                now = datetime.now()
                slug = "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in (title or "Dictation").lower())[:30]
                filename = f"{now.strftime('%Y-%m-%d-%H%M')}_{slug}.md"
                filepath = os.path.join(DICTATIONS_DIR, filename)
                
                content = f"""# {title or 'Voice Session'}
> **Timestamp**: {now.strftime('%Y-%m-%d %H:%M:%S')}  
> **Source**: Voice Studio Pro ({action})

---

{text}
"""
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(content)
                
                self._send_json({
                    "success": True,
                    "filename": filename,
                    "path": filepath
                })
            except Exception as e:
                self._send_json({"error": str(e)}, status=500)
            return

        # Save config endpoint
        elif self.path == "/api/config":
            body = self.rfile.read(content_length).decode("utf-8")
            try:
                new_cfg = json.loads(body)
                cfg = load_config()
                cfg.update(new_cfg)
                save_config(cfg)
                self._send_json({"success": True, "config": cfg})
            except Exception as e:
                self._send_json({"error": str(e)}, status=500)
            return

        # Set Mic Source endpoint
        elif self.path == "/api/set-mic":
            body = self.rfile.read(content_length).decode("utf-8")
            try:
                data = json.loads(body)
                mic_key = data.get("mic", "mic1")
                apply_mic_source(mic_key)
                cfg = load_config()
                cfg["selected_mic"] = mic_key
                save_config(cfg)
                self._send_json({"success": True, "selected_mic": mic_key})
            except Exception as e:
                self._send_json({"error": str(e)}, status=500)
            return

        # Window resize mode endpoint (Bubble, Compact, Full)
        elif self.path == "/api/window/resize":
            body = self.rfile.read(content_length).decode("utf-8")
            try:
                data = json.loads(body)
                mode = data.get("mode", "compact")
                cfg = load_config()
                cfg["ui_mode"] = mode
                save_config(cfg)

                # Resize window via wmctrl
                if mode == "bubble":
                    subprocess.run(["wmctrl", "-r", "Voice Studio", "-e", "0,-1,-1,220,260"], check=False)
                elif mode == "compact":
                    subprocess.run(["wmctrl", "-r", "Voice Studio", "-e", "0,-1,-1,380,480"], check=False)
                elif mode == "full":
                    subprocess.run(["wmctrl", "-r", "Voice Studio", "-e", "0,-1,-1,560,660"], check=False)

                self._send_json({"success": True, "mode": mode})
            except Exception as e:
                self._send_json({"error": str(e)}, status=500)
            return

        self.send_response(404)
        self.end_headers()

    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

def run_server(port=4321):
    with ThreadedTCPServer(("127.0.0.1", port), StudioRequestHandler) as httpd:
        print(f"[VOICE_STUDIO] Threaded Server online at http://127.0.0.1:{port}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("[VOICE_STUDIO] Shutting down.")

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 4321
    run_server(port)
