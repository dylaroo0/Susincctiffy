#!/usr/bin/env bash
set -euo pipefail
export DISPLAY="${DISPLAY:-:0.0}"
export XAUTHORITY="${XAUTHORITY:-$HOME/.Xauthority}"

SCRIPT_DIR="/home/roo/Documents/PROJECTS OF FOCUS/vault/projects/voice-studio"
cd "$SCRIPT_DIR"

# 1. Resolve Python Binary
PYTHON_BIN=""
if [ -f "$SCRIPT_DIR/.venv/bin/python" ]; then
  PYTHON_BIN="$SCRIPT_DIR/.venv/bin/python"
elif [ -f "$HOME/Music/TalkToMe-v2.0/.venv/bin/python" ]; then
  PYTHON_BIN="$HOME/Music/TalkToMe-v2.0/.venv/bin/python"
elif command -v python3 >/dev/null 2>&1; then
  PYTHON_BIN="$(command -v python3)"
else
  echo "Error: Python 3 not found!" >&2
  exit 1
fi

# 2. Check if Server is already listening on Port 4321
if ! curl -s http://127.0.0.1:4321/api/config >/dev/null 2>&1; then
  echo "Starting Voice Studio Pro Server on port 4321..."
  pkill -f "$SCRIPT_DIR/server.py" 2>/dev/null || true
  nohup "$PYTHON_BIN" "$SCRIPT_DIR/server.py" 4321 > "$SCRIPT_DIR/server.log" 2>&1 &
  disown

  # Wait for server ready (up to 6 seconds)
  for i in {1..30}; do
    if curl -s http://127.0.0.1:4321/api/config >/dev/null 2>&1; then
      echo "Server is online!"
      break
    fi
    sleep 0.2
  done
else
  echo "Voice Studio server already running on port 4321."
fi

# 3. Focus existing window or launch in isolated Brave app window
WINDOW_ID=$(wmctrl -l | grep -i "Voice Studio" | awk '{print $1}' | head -n 1 || true)
if [ -n "$WINDOW_ID" ]; then
  echo "Activating existing Voice Studio window..."
  wmctrl -i -a "$WINDOW_ID" 2>/dev/null || true
else
  echo "Opening Voice Studio UI in native app mode..."
  if command -v brave-browser >/dev/null 2>&1; then
    brave-browser --user-data-dir="$HOME/.config/voice-studio-native" --app="http://127.0.0.1:4321" --window-size=480,720 >/dev/null 2>&1 &
  elif command -v firefox >/dev/null 2>&1; then
    firefox --new-window "http://127.0.0.1:4321" >/dev/null 2>&1 &
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://127.0.0.1:4321" >/dev/null 2>&1 &
  fi
fi

echo "Voice Studio Pro ready!"
